package com.song.nuclear_craft.world.gen;

import net.minecraft.world.biome.Biome;
import net.minecraftforge.registries.ForgeRegistries;

public class OreGen {
    public static void generateOre(){
    }
}
